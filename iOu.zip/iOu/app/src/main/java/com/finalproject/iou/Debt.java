package com.finalproject.iou;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Debt extends AppCompatActivity {

    Dialog customDialog;
    Intent recieveIntent, backIntent;
    Bundle rBundle;
    int user_id, t_id;
    List<transactionDetails> debtList;
    ImageView imgBackBtn, imgAddBtn;
    TextView etAmount, etName, etNote, etExptDate,tvTitle,tvTotalValue;
    Button btnAdd;
    Double TotalSum = 0.0;
    public static Double TotalDebt= 0.0;

    private RecyclerView recyclerTransactions;
    LinearLayoutManager layoutManager;
    MyRecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.debt_layout);
        tvTotalValue = findViewById(R.id.tvTotalValue);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        recieveIntent = getIntent();
        rBundle = recieveIntent.getExtras();
        user_id = rBundle.getInt("user_id");
        t_id = rBundle.getInt("t_id");

        recyclerTransactions = findViewById(R.id.recyclerTransactions);
        imgBackBtn = findViewById(R.id.imgBackBtn);
        imgAddBtn = findViewById(R.id.imgAddBtn);

        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerTransactions.setLayoutManager(layoutManager);
        recyclerTransactions.hasFixedSize();

        debtList = TransactionDB.findTransactions(MainActivity.dbHelper,user_id,t_id);
        Collections.reverse(debtList);
        adapter = new MyRecyclerViewAdapter(Debt.this, (ArrayList<transactionDetails>) debtList, recyclerTransactions,1);
        recyclerTransactions.setAdapter(adapter);

        createDialog();

        imgAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customDialog.show();
            }
        });

        for(int i = 0;i < debtList.size();i++){
            TotalSum += Double.parseDouble(debtList.get(i).getAmount());
        }
        TotalDebt = TotalSum;
        tvTotalValue.setText(""+TotalSum);
    }

    public void createDialog(){
        customDialog = new Dialog(this);
        customDialog.setContentView(R.layout.custom_dialogue_box);

        etAmount =customDialog.findViewById(R.id.etAmount);
        etName = customDialog.findViewById(R.id.etName);
        etNote = customDialog.findViewById(R.id.etNote);
        etExptDate = customDialog.findViewById(R.id.etExptDate);
        btnAdd = customDialog.findViewById(R.id.btnAdd);
        tvTitle = customDialog.findViewById(R.id.tvTitle);
        tvTitle.setText("Add Data");

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newAmount = etAmount.getText().toString();
                String newName = etName.getText().toString();
                String newNote = etNote.getText().toString();
                String newExpDate = etExptDate.getText().toString();

                transactionDetails newData = TransactionDB.insertTransaction(MainActivity.dbHelper,1, newName, MainActivity.session, newAmount, newNote,  newExpDate);
                debtList.add(newData);
                adapter = new MyRecyclerViewAdapter(Debt.this, (ArrayList<transactionDetails>) debtList, recyclerTransactions,1);
                recyclerTransactions.setAdapter(adapter);
                Collections.reverse(debtList);
                TotalSum += Double.parseDouble(newAmount);
                tvTotalValue.setText("$ "+TotalSum);
                etAmount.setText("");
                etName.setText("");
                etNote.setText("");
                etExptDate.setText("");
                customDialog.dismiss();
            }
        });

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerTransactions);
    }
        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                if (direction == ItemTouchHelper.LEFT){
                    TotalSum -= Double.parseDouble(debtList.get(position).getAmount());
                    tvTotalValue.setText(""+TotalSum);
                    TransactionDB.deleteTransaction(MainActivity.dbHelper,debtList.get(position).getId());
                    debtList.remove(position);
                    adapter.notifyItemRemoved(position);
                }
            }
            @Override
            public int getMovementFlags(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder) {
                int swipeFlags = ItemTouchHelper.LEFT;
                return makeMovementFlags(0,swipeFlags);
            }
        };

    public void onClick(View view) {
        backIntent = new Intent(this,Dashboard.class);
        Bundle sendB = new Bundle();
        sendB.putString("uname",MainActivity.uname);
        sendB.putInt("session",MainActivity.session);
        backIntent.putExtras(sendB);
        TotalDebt = TotalSum;
        TotalSum = 0.0;
        startActivity(backIntent);
    }
}
