package com.finalproject.iou;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.MyRecyclerViewItemHolder> {
    private Context context;
    private ArrayList<transactionDetails> recyclerItemValues;
    private RecyclerView recyclerView;
    Dialog customDialog;
    TextView etAmount, etName, etNote, etExptDate, tvTitle;
    Button btnAdd;
    int checkIndex = 0;


    public MyRecyclerViewAdapter(Context context, ArrayList<transactionDetails> values, RecyclerView recyclerView, int checkIndex){
        this.context = context;
        this.recyclerItemValues = values;
        this.recyclerView = recyclerView;
        this.checkIndex = checkIndex;
    }

    @NonNull
    @Override
    public MyRecyclerViewItemHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflator = LayoutInflater.from(viewGroup.getContext());
        View itemView = inflator.inflate(R.layout.recycler_layout, viewGroup, false);
        MyRecyclerViewItemHolder mViewHolder = new MyRecyclerViewItemHolder(itemView);
        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyRecyclerViewItemHolder myRecyclerViewItemHolder, int i) {
        if(checkIndex ==1){
            myRecyclerViewItemHolder.imgCurrency.setImageResource(R.drawable.ic_monetization_on_black_24dp);
        }
        else {
            myRecyclerViewItemHolder.imgCurrency.setImageResource(R.drawable.ic_attach_money_black_24dp);
        }

        final int position = i;
        final transactionDetails td = recyclerItemValues.get(i);

        final String res = "Name: " +td.getName()+
                "\nAmount: "+td.getAmount()+
                "\nNote" +td.getNotes()+
                "\nExpected Date of return: "+td.getExpDate();

        myRecyclerViewItemHolder.tvName.setText(td.getName());
        myRecyclerViewItemHolder.tvAmount.setText(td.getAmount());

        myRecyclerViewItemHolder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customDialog = new Dialog(context);
                customDialog.setContentView(R.layout.custom_dialogue_box);
                customDialog.show();
                etAmount =customDialog.findViewById(R.id.etAmount);
                etName = customDialog.findViewById(R.id.etName);
                etNote = customDialog.findViewById(R.id.etNote);
                etExptDate = customDialog.findViewById(R.id.etExptDate);
                btnAdd = customDialog.findViewById(R.id.btnAdd);
                tvTitle = customDialog.findViewById(R.id.tvTitle);
                btnAdd.setText("Modify");
                tvTitle.setText("Modify Data");


                etAmount.setText(td.getAmount());
                etName.setText(td.getName());
                etNote.setText(td.getNotes());
                etExptDate.setText(td.getExpDate());

                btnAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String newAmount = etAmount.getText().toString();
                        String newName = etName.getText().toString();
                        String newNote = etNote.getText().toString();
                        String newExpDate = etExptDate.getText().toString();

                        TransactionDB.updateTransactions(MainActivity.dbHelper,td.getId(),newName,newAmount,newNote,newExpDate);
                        td.setAmount(newAmount);
                        td.setName(newName);
                        td.setNotes(newNote);
                        td.setExpDate(newExpDate);
                        customDialog.dismiss();
                    }
                });
            }
        });

        myRecyclerViewItemHolder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeAndShowDialogBox(res);
            }
        });
    }

//    @Override
//    public int getItemViewType(int position) {
//
//        if (recyclerItemValues.get(position). ) {
//            return 1;
//        } else {
//            return 0;
//        }
//    }

    @Override
    public int getItemCount() {
        return recyclerItemValues.size();
    }



    class MyRecyclerViewItemHolder extends  RecyclerView.ViewHolder{
        TextView tvName ;
        TextView tvAmount;
        ImageView imgCurrency;
        ImageView btnEdit;
        ConstraintLayout parentLayout;
        public MyRecyclerViewItemHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            imgCurrency = itemView.findViewById(R.id.imgCurrency);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            parentLayout = itemView.findViewById(R.id.constLayout);
        }
    }

//    private void deleteItem(int position) {
//
//        if (recyclerItemValues.size() > 0) {
//            recyclerItemValues.remove(position);  //Remove the current content from the array
//            notifyItemRemoved(position);
//            notifyItemRangeChanged(position, recyclerItemValues.size());//Refresh list
//        }
//    }


    private void makeAndShowDialogBox(String message) {
        AlertDialog.Builder mDialogBox = new AlertDialog.Builder(context);
        mDialogBox.setTitle("Details");
        mDialogBox.setMessage(message);
        mDialogBox.setPositiveButton("Close",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    }
                });
        mDialogBox.create();
        mDialogBox.show();
    }

}
