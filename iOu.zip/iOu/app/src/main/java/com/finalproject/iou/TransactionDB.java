package com.finalproject.iou;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TransactionDB {

    public static final String TABLE_NAME ="transactions";
    public static final String FIELD_ID = "_id";
    public static final String FIELD_TID = "t_id";
    public static final String FIELD_AMOUNT = "_amount";
    public static final String FIELD_NAME = "_name";
    public static final String FIELD_USERID = "_userId";
    public static final String FIELD_NOTE = "_note";
    public static final String FIELD_EXP_RETURN = "_expReturn";

    public static final String CREATE_TABLE_SQL = "CREATE TABLE "+TABLE_NAME+" ("+FIELD_ID+" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "+FIELD_TID+" number, "+FIELD_AMOUNT+" text, "
            +FIELD_NAME+" text, "+FIELD_USERID+" number, "+FIELD_NOTE+" text, "+FIELD_EXP_RETURN+" text);";

    public static final String DROP_TABLE_SQL = "DROP TABLE if exists "+TABLE_NAME;


//    public static List<transactionDetails> getAllTransactions(DatabaseHelper db){
//
//        Cursor cursor = db.getAllRecords(TABLE_NAME, null);
//        //Cursor cursor  db.getAllRecordsMethod2("SELECT * FROM "+TABLE_NAME, null)
//        List<transactionDetails> data=new ArrayList<>();
//        transactionDetails aDetail = null;
//        while (cursor.moveToNext()) {
//           int id = cursor.getInt(0);
//           String name = cursor.getString(1);
//           String email = cursor.getString(2);
//
//            aDetail= new transactionDetails(id, name,email );
//           data.add(aDetail);
//        }
//        return data;
//    }
    public static List<transactionDetails> findTransactions(DatabaseHelper db, int user_id, int t_id ){

        String where = FIELD_USERID+" like '%"+user_id+"%' and "+FIELD_TID+" like '%"+t_id+"%'";
        Cursor cursor = db.getSomeRecords(TABLE_NAME,null, where);
        List<transactionDetails> data = new ArrayList<>();
        transactionDetails aTrans = null;
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            int tid = cursor.getInt(1);
            String amount = cursor.getString(2);
            String name = cursor.getString(3);
            int uid = cursor.getInt(4);
            String note = cursor.getString(5);
            String espDate = cursor.getString(6);

            aTrans= new transactionDetails(id,t_id,uid, name,  amount, note, espDate);
            data.add(aTrans);
        }
        return data;
    }

    public static int getLastAddedRowId() {
        String queryLastRowInserted = "select last_insert_rowid()";

        final Cursor cursor = DatabaseHelper.db.rawQuery(queryLastRowInserted, null);
        int _idLastInsertedRow = 0;
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    _idLastInsertedRow = cursor.getInt(0);
                }
            } finally {
                cursor.close();
            }
        }

        return _idLastInsertedRow;

    }

    public static transactionDetails insertTransaction(DatabaseHelper db, int t_id, String name, int user_id, String amount, String note, String expReturn){
        ContentValues contentValues = new ContentValues( );
        contentValues.put(FIELD_TID,t_id);
        contentValues.put(FIELD_AMOUNT,amount);
        contentValues.put(FIELD_NAME, name);
        contentValues.put(FIELD_USERID, user_id);
        contentValues.put(FIELD_NOTE, note);
        contentValues.put(FIELD_EXP_RETURN,expReturn);

        db.insert(TABLE_NAME,contentValues);
        transactionDetails td = new transactionDetails(getLastAddedRowId(),t_id, user_id, name, amount, note, expReturn);
        return td;
    }
    public static boolean updateTransactions(DatabaseHelper db, int id, String name, String amount, String note, String expReturn){
        ContentValues contentValues = new ContentValues( );
        contentValues.put(FIELD_NAME, name);
        contentValues.put(FIELD_AMOUNT, amount);
        contentValues.put(FIELD_NOTE, note);
        contentValues.put(FIELD_EXP_RETURN, expReturn);
        String where = FIELD_ID +" = "+id;

        boolean res = db.update(TABLE_NAME,contentValues,where);

        return res;
    }
    public static boolean isTransactionExist(DatabaseHelper db, int id){
        String where = FIELD_ID +" = '"+id+"'";
        Cursor cursor = db.getSomeRecords(TABLE_NAME,null, where);
        if(cursor.moveToNext()){
            return true;
        }
        return  false;
    }
    public static boolean deleteTransaction(DatabaseHelper db, int id){
        String where = FIELD_ID +" = "+ id;
        boolean res = db.delete(TABLE_NAME,where);
        return res;
    }
}
