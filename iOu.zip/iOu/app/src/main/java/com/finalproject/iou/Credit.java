package com.finalproject.iou;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Credit extends AppCompatActivity {

    Dialog customDialog;
    Intent recieveIntent, backIntent;
    Bundle rBundle;
    int user_id, t_id;
    List<transactionDetails> creditList;
    ImageView imgAddBtn;
    TextView etAmount, etName, etNote, etExptDate,tvTitle,tvTotalValue;
    Button btnAdd;
    Double TotalCreditSum = 0.0;
    public static Double TotalCred = 0.0;


    private RecyclerView recyclerTransactions;
    LinearLayoutManager layoutManager;
    MyRecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.credit_layout);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        recieveIntent = getIntent();
        rBundle = recieveIntent.getExtras();
        user_id = rBundle.getInt("user_id");
        t_id = rBundle.getInt("t_id");

        recyclerTransactions = findViewById(R.id.recyclerTransactions);
        imgAddBtn = findViewById(R.id.imgAddBtn);
        tvTotalValue = findViewById(R.id.tvTotalValue);

        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerTransactions.setLayoutManager(layoutManager);
        recyclerTransactions.hasFixedSize();

        creditList = TransactionDB.findTransactions(MainActivity.dbHelper,user_id,t_id);
        adapter = new MyRecyclerViewAdapter(Credit.this, (ArrayList<transactionDetails>) creditList, recyclerTransactions,0);
        recyclerTransactions.setAdapter(adapter);

        createDialog();

        imgAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customDialog.show();
            }
        });

        for(int i = 0;i < creditList.size();i++){
            TotalCreditSum += Double.parseDouble(creditList.get(i).getAmount());
        }
        TotalCred = TotalCreditSum;
        tvTotalValue.setText(""+TotalCreditSum);

    }

    public void createDialog(){
        customDialog = new Dialog(this);
        customDialog.setContentView(R.layout.custom_dialogue_box);

        etAmount =customDialog.findViewById(R.id.etAmount);
        etName = customDialog.findViewById(R.id.etName);
        etNote = customDialog.findViewById(R.id.etNote);
        etExptDate = customDialog.findViewById(R.id.etExptDate);
        btnAdd = customDialog.findViewById(R.id.btnAdd);
        tvTitle = customDialog.findViewById(R.id.tvTitle);
        tvTitle.setText("Add Data");

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newAmount = etAmount.getText().toString();
                String newName = etName.getText().toString();
                String newNote = etNote.getText().toString();
                String newExpDate = etExptDate.getText().toString();

                transactionDetails newData = TransactionDB.insertTransaction(MainActivity.dbHelper,2, newName, MainActivity.session, newAmount, newNote,  newExpDate);
                creditList.add(newData);
                adapter = new MyRecyclerViewAdapter(Credit.this, (ArrayList<transactionDetails>) creditList, recyclerTransactions,2);
                recyclerTransactions.setAdapter(adapter);
//                Collections.reverse(debtList);
                TotalCreditSum += Double.parseDouble(newAmount);
                tvTotalValue.setText("$ "+TotalCreditSum);
                etAmount.setText("");
                etName.setText("");
                etNote.setText("");
                etExptDate.setText("");
                customDialog.dismiss();
            }
        });

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerTransactions);
    }

    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
           int position = viewHolder.getAdapterPosition();
            if (direction == ItemTouchHelper.LEFT){
                TotalCreditSum -= Double.parseDouble(creditList.get(position).getAmount());
                tvTotalValue.setText(""+TotalCreditSum);
                TransactionDB.deleteTransaction(MainActivity.dbHelper,creditList.get(position).getId());
                creditList.remove(position);
                adapter.notifyItemRemoved(position);
            }
        }

        @Override
        public int getMovementFlags(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder) {
            int swipeFlags = ItemTouchHelper.LEFT;
            return makeMovementFlags(0,swipeFlags);
        }
    };


    public void onClick(View view) {
        backIntent = new Intent(this,Dashboard.class);
        Bundle sendB = new Bundle();
        sendB.putString("uname",MainActivity.uname);
        sendB.putInt("session",MainActivity.session);
        backIntent.putExtras(sendB);
        TotalCred = TotalCreditSum;
        TotalCreditSum = 0.0;
        startActivity(backIntent);
    }
}
