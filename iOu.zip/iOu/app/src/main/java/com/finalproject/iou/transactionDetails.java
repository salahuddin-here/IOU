package com.finalproject.iou;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;

public class transactionDetails implements Parcelable {

    private int id , t_id, user_id;
    private String name, amount, notes;
    private String expDate;

    public transactionDetails(int id, int t_id, int user_id, String name, String amount, String notes, String expDate) {
        this.id = id;
        this.t_id = t_id;
        this.user_id = user_id;
        this.name = name;
        this.amount = amount;
        this.notes = notes;
        this.expDate = expDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getT_id() {
        return t_id;
    }

    public void setT_id(int t_id) {
        this.t_id = t_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getExpDate() {
        return expDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    protected transactionDetails(Parcel in) {
        id = in.readInt();
        t_id = in.readInt();
        user_id = in.readInt();
        name = in.readString();
        amount = in.readString();
        notes = in.readString();
        expDate = in.readString();
    }

    public static final Creator<transactionDetails> CREATOR = new Creator<transactionDetails>() {
        @Override
        public transactionDetails createFromParcel(Parcel in) {
            return new transactionDetails(in);
        }

        @Override
        public transactionDetails[] newArray(int size) {
            return new transactionDetails[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeInt(t_id);
        dest.writeInt(user_id);
        dest.writeString(name);
        dest.writeString(amount);
        dest.writeString(notes);
        dest.writeString(expDate);
    }
}
