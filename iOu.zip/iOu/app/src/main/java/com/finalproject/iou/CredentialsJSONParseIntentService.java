package com.finalproject.iou;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;


public class CredentialsJSONParseIntentService extends IntentService {
    private String jsonStr;
    private JSONArray cred;
    private JSONObject credJSONObject;

    Bundle receievedBundle;

    public static final String TAG_CREDENTIALS = "credentials";
    public static final String TAG_USERNAME = "username";
    public static final String TAG_PASSWORD = "password";
    public static final String TAG_SECTIONID= "sectionId";


    boolean flag = false;
    Integer sessionId;
    String username;

    public CredentialsJSONParseIntentService() {
        super("CredentialsJSONParseIntentService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {


        receievedBundle = intent.getExtras();
        String revUsername  = receievedBundle.getString("username");
        String revPassword  = receievedBundle.getString("password");

        Log.d("IntentService============================================", "Service Started");
        jsonStr = loadFileFromAssets("credentials.json");

        if (jsonStr != null) {
            try {
                credJSONObject = new JSONObject(jsonStr);
                cred = credJSONObject.getJSONArray(TAG_CREDENTIALS);


                for (int i = 0; i < cred.length(); i++) {

                    JSONObject c = cred.getJSONObject(i);

                    sessionId = c.getInt(TAG_SECTIONID);
                    username = c.getString(TAG_USERNAME);
                    String password = c.getString(TAG_PASSWORD);

                    if(username.compareTo(revUsername) ==0  && password.compareTo(revPassword) ==0 ){
                        flag = true;
                        break;
                    }
                }

            } catch (JSONException ee) {
                ee.printStackTrace();
            }
        }

        Bundle bundle=new Bundle();
        bundle.putBoolean("result",flag);
        bundle.putInt("session_ID",sessionId);
        bundle.putString("uname", username);

        Intent broadcastIntent = new Intent();

        broadcastIntent.setAction("CREDENTIALS_COMING_ACTION");
        broadcastIntent.putExtras(bundle);
        sendBroadcast(broadcastIntent);

    }
    private String loadFileFromAssets(String fileName) {
        String fileContent = null;
        try {

            InputStream is = getBaseContext().getAssets().open(fileName);

            int size = is.available();
            byte[] buffer = new byte[size];

            is.read(buffer);
            is.close();

            fileContent = new String(buffer, "UTF-8");

        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return fileContent;
    }


}
